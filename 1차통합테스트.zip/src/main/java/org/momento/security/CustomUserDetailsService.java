package org.momento.security;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.momento.domain.AuthVO;
import org.momento.domain.MemberVO;
import org.momento.mapper.MemberMapper;
import org.momento.security.domain.CustomUser;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
public class CustomUserDetailsService implements UserDetailsService {

	@Setter(onMethod_ = { @Autowired })
	private MemberMapper memberMapper;

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {

		log.warn("Load User By UserName : " + userName);

		// userName means userid
		MemberVO vo = memberMapper.read(userName);

		log.warn("queried by member mapper: " + vo);
			
		AuthVO auth = new AuthVO();
		auth.setUserid(vo.getUserid());
		auth.setAuth("ROLE_USER");

		List<AuthVO> authList = new ArrayList<>();
		authList.add(auth);

		vo.setAuthList(authList);
		
		log.warn(vo);

		return vo == null ? null : new CustomUser(vo);
	}

}
