//배경설정
 var images = [
            "https://wallup.net/wp-content/uploads/2019/09/726722-landscape.jpg",
            "https://wallpaperaccess.com/full/343619.jpg",
            "https://images8.alphacoders.com/131/1318148.png",
            "https://wallpapers.com/images/hd/blue-aesthetic-moon-df8850p673zj275y.jpg",
            "https://w.forfun.com/fetch/b4/b499df2260fd44cf6cd641d011017501.jpeg",
            "https://wallpapers.com/images/hd/scenic-apennine-mountains-7d5qa9cja90xhd2h.jpg",
            // 랜덤 이미지 URL 추가
        ];

        function getRandomImage() {
            var randomIndex = Math.floor(Math.random() * images.length);
            var imageUrl = images[randomIndex];
            document.body.style.backgroundImage = "url('" + imageUrl + "')";
        }

        window.addEventListener("load", getRandomImage);
        
    
    //시계
    function printClock() {
      var clock = document.getElementById("clock");
      var currentDate = new Date();
      var currentHours = currentDate.getHours() % 12 || 12;
      var currentMinute = addZeros(currentDate.getMinutes(), 2);
      var amPm = currentDate.getHours() >= 12 ? 'PM' : 'AM'; // AM/PM 설정

      var formattedTime =
        currentHours +
        ":" +
        currentMinute +
        "<span style='font-size: medium;'>" +
        amPm +
        "</span>"; // 시간과 AM/PM 표시를 포맷에 맞게 조합

      clock.innerHTML = formattedTime; // 시간을 출력해 줌

      setTimeout(printClock, 1000); // 1초마다 printClock() 함수 호출
    }

    function addZeros(num, digit) {
      var zero = "";
      num = num.toString();
      if (num.length < digit) {
        for (i = 0; i < digit - num.length; i++) {
          zero += "0";
        }
      }
      return zero + num;
    }

    printClock();

	//메뉴 버튼
	  
    function toggleContent() {
      var toggleContainer = document.querySelector('.toggle-container');
      toggleContainer.classList.toggle('active');
      
      var toggleIcon = document.querySelector('.toggle-icon');
      toggleIcon.classList.toggle('active');
      
    }
    


        