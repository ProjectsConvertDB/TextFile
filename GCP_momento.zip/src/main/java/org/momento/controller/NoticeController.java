package org.momento.controller;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.momento.domain.NoticeAttachVO;
import org.momento.domain.NoticeVO;
import org.momento.domain.Criteria;
import org.momento.domain.MemberVO;
import org.momento.domain.PageDTO;
import org.momento.domain.ReferralVO;
import org.momento.security.domain.CustomUser;
import org.momento.service.NoticeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/notice/*")
@AllArgsConstructor
public class NoticeController {

	private NoticeService service;

	/* 전체글 페이지 */
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/l_01")
	public void list(Criteria cri, Model model) {

		model.addAttribute("list", service.getList(cri));

		int total = service.getTotal(cri);

		model.addAttribute("pageMaker", new PageDTO(cri, total));

	}

	/* 삭제글 페이지 */
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/l_02")
	public void deletedList(Criteria cri, Model model) {

		model.addAttribute("deletedList", service.getDeletedList(cri));

		int deleted = service.getDeleted(cri);

		model.addAttribute("pageMaker", new PageDTO(cri, deleted));

	}
	
	/* 삭제글 체크 */
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/l_03")
	public String deleteCheckedAll(@RequestParam("checklist") Long[] bnos, @RequestParam("del_res") String del_res,
			Criteria cri, Model model) {

		service.removeMulti(bnos, del_res);

		return "redirect:/notice/l_01";

	}

	/* 등록 페이지 */
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/w_01")
	public void register() {
	}
	
	/* 등록 데이터 전송 */
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/w_01")
	public String register(NoticeVO notice, RedirectAttributes rttr) {
		
		if (notice.getAttachVO() != null) {
			log.info(notice.getAttachVO());
		}
		
		if (notice.getFixed() != '1') {
			notice.setFixed('0');
		}
		
		service.register(notice);

		rttr.addFlashAttribute("result", notice.getBno());

		return "redirect:/notice/l_01";

	}
	
	/* 조회 페이지 */
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/r_01")
	public void get( @RequestParam("bno") Long bno, @ModelAttribute("cri") Criteria cri, Model model) {

		MemberVO member = null;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		
		if (authentication.getPrincipal() instanceof CustomUser) {
            CustomUser customUser = (CustomUser) authentication.getPrincipal();
            member = customUser.getMember();
		}
		
		ReferralVO referral = new ReferralVO();
		referral.setUser_id(member.getUserid());
		referral.setBno(bno);
		
		model.addAttribute("notice", service.get(bno));
		model.addAttribute("isReferral", service.getReferrals(referral));

	}

	/* 수정 정보 전송 */
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/m_01")
	public String modify(NoticeVO notice, @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {

		if (service.modify(notice)) {
			rttr.addFlashAttribute("result", "success");
		}

		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		rttr.addAttribute("type", cri.getType());
		rttr.addAttribute("keyword", cri.getKeyword());

		return "redirect:/notice/l_01" + cri.getListLink();

	}

	/* 삭제 정보 전송 */
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/d_01")
	public String remove(@RequestParam("bno") Long bno, Criteria cri, RedirectAttributes rttr) {
		
		NoticeAttachVO attach = service.getAttachVO(bno);
		
		if (service.remove(bno)) {
			
			deleteFiles(attach);
			
			rttr.addFlashAttribute("result", "success");
		}
		
		return "redirect:/notice/l_01" + cri.getListLink();
		
	}

	/* 업로드 파일 데이터 전송 */
	@PreAuthorize("isAuthenticated()")
	@GetMapping(value = "/getFile", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
	public ResponseEntity<NoticeAttachVO> getAttachVO(Long bno) {

		log.info("getAttachVO" + bno);
		
		NoticeAttachVO vo = service.getAttachVO(bno);

		return vo==null ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(vo , HttpStatus.OK);
		
	}
	
	/* 추천 데이터 전송 */
	@PreAuthorize("isAuthenticated()")
	@PostMapping(value = "/r_03", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
	public ResponseEntity<Boolean> referral(ReferralVO referral) {

		if (service.referral(referral)) {
			return new ResponseEntity<Boolean>(service.getReferrals(referral), HttpStatus.OK);
		} else {
			return new ResponseEntity<Boolean>( false , HttpStatus.NO_CONTENT);
		}

	}

	/* 파일 삭제 */
	private void deleteFiles(NoticeAttachVO attach) {

		if (attach == null) {
			return;
		}

		log.info("delete attach file...................");
		log.info(attach);

		try {
			Path file = Paths.get(
					"/opt/tomcat/webapps/momento/resources/upload/" + attach.getUploadPath() + "\\" + attach.getUuid() + "_" + attach.getFileName());

			Files.deleteIfExists(file);

		} catch (Exception e) {
			log.error("delete file error" + e.getMessage());
		} // end catch

	}

}
