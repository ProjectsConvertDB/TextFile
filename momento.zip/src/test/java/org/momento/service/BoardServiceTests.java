package org.momento.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.momento.domain.BoardVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardServiceTests {

	@Setter(onMethod_ = {@Autowired}) // 중괄호 -> 여러개 사용 가능
	private BoardService service;
	
	// 객체 자동 주입 확인
	@Test
	public void testExist() {
		
		log.info(service);
		assertNotNull(service);
		
	}
	
	// 등록 테스트
	@Test
	public void testRegister() {
		
		BoardVO board = new BoardVO();
		board.setTitle("serviceTitle1");
		board.setContent("serviceContent1");
		
		service.register(board);
		log.info("등록된 게시물 번호 : " + board.getBno());
		
	}
	
	// 목록 조회 테스트
	@Test
	public void getList() {}
	
	@Test
	public void testGet() {
		
		log.info(service.get(5L));
		
	}
	
	@Test
	public void testDelete() {
		
		log.info(service.remove(5L));
		
	}
	
	@Test
	public void testUpdate() {
		
		BoardVO board = service.get(5L);

		if (board == null) return;
		
		board.setContent("serviceUpdate1");
		log.info(service.modify(board));
		
	}
	
}
