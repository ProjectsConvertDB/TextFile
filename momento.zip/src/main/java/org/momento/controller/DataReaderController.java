package org.momento.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/reader/*")
public class DataReaderController {	
	
	@GetMapping("/csvreader")
	public void csvReader() { 
		
		
	}
	
	
	@GetMapping("/qqqq")
	public void qqqq(@RequestParam("test") String test, Model model) {
		
		FileReader_1 csvReader = new FileReader_1(test);
		
		model.addAttribute("csvread", csvReader.readCSV());
		
	}
	
}
