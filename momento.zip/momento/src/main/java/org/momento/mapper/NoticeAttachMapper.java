package org.momento.mapper;

import java.util.List;

import org.momento.domain.NoticeAttachVO;

public interface NoticeAttachMapper {

	/* 파일 데이터 삽입 */
	public void insert(NoticeAttachVO vo);
	
	/* 파일 데이터 삭제 */
	public void delete(Long Bno);
	
	/* `bno'번 글 조회 */
	public NoticeAttachVO findByBno(Long bno);
	
	/* 잘못 업로드된 파일 삭제 */
	public List<NoticeAttachVO> getOldFiles();
	
}
