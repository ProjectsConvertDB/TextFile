package org.momento.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.momento.domain.NoticeVO;
import org.momento.domain.Criteria;
import org.momento.domain.ReferralVO;

public interface NoticeMapper {

	/* 전체글 리스트 */
	public List<NoticeVO> getList();

	/* 전체글 페이징 */
	public List<NoticeVO> getListWithPaging(Criteria cri);

	/* 전체글 카운팅 */
	public int getTotalCount(Criteria cri);
	
	/* 삭제글 리스트 */
	public List<NoticeVO> getDeletedList();
	
	/* 삭제글 페이징 */
	public List<NoticeVO> getDeletedListWithPaging(Criteria cri);
	
	/* 삭제글 카운팅 */
	public int getDeletedCount(Criteria cri);
	
	/* 공지글 리스트 */
	public List<NoticeVO> getFixedList();
	
	/* 인기글 리스트 */
	public List<NoticeVO> getHotList();

	/* 글 등록 */
	public void insert(NoticeVO board);

	public Integer insertSelectKey(NoticeVO board);

	/* 글 조회 */
	public NoticeVO read(Long bno);

	/* 글 수정 */
	public int update(NoticeVO board);
	
	/* 글 삭제 */
	public int delete(Long bno);
	
	/* 글 복구 */
	public int restore(Long bno);
	
	/* 조회수 */
	public void views(Long bno);

	/* 추천글 데이터 조회 */
	public int getReferral(ReferralVO referral);
	
	/* 추천글 데이터 삽입 */
	public void insertReferral(ReferralVO referral);
	
	/* 추천글 데이터 삭제 */
	public void deleteReferral(ReferralVO referral);
	
	/* 추천수 컨트롤 */
	public int updateReferrals(@Param("referralCnt")int referralCnt, @Param("bno")Long bno);
	
}
