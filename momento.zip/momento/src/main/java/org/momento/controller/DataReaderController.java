package org.momento.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/reader/*")
public class DataReaderController {	
	
	@GetMapping("/csvreader")
	public void csvReader(Model model) { 
		
		FileReader_1 csvReader = new FileReader_1();
		
		model.addAttribute("csvread", csvReader.readCSV());
		
	}
	
}
