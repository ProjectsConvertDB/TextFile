package org.momento.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.mozilla.universalchardet.UniversalDetector;

public class SqlFile {
	public String title;
	public SqlFile(String test) {
		 title = test;
		 
		 return;
	}
	
	// 파일 인코딩 형식 반환 
	public String detectorFile(File file) throws java.io.IOException {
		String encoding = UniversalDetector.detectCharset(file);
		if (encoding != null) {
			return "MS949";
		} else {
			return "UTF-8";
		}
	}
	
	// 파일 읽기
	public List<List<String>> readSQL() throws IOException {
	        List<List<String>> csvList = new ArrayList<List<String>>();
	        
	        //file 명 받아와서 출력 
	        String name = "upload.csv";
	        File csv = new File("C://upload/"+name+"");
	        
	        BufferedReader br = null;
	        String line = "";
	        
	        int p = 0;
	        try {
	        	
	        	Charset charset = Charset.forName(detectorFile(csv));
	            br = new BufferedReader(new InputStreamReader(new FileInputStream(csv), charset));
	            
	            while ((line = br.readLine()) != null) {
	               
	               List<String> aLine = new ArrayList<String>();
	               
	               String[] lineArr = line.replace("[","").replace("]","").split(","); 
	               if(p == 0) {
	                  int i=0;
	                      for(String s : lineArr) {
	                      
	                      if(i==0) {
	                         lineArr[i] = "create table "+ title +" ("+lineArr[i]+" varchar2(150) ";
	                      }
	                      else if(i == lineArr.length-1) {
	                         lineArr[i] =lineArr[i]+" varchar2(150) );";
	                      }
	                      else {
	                         lineArr[i] = lineArr[i]+" varchar2(150)";
	                      }
	                      System.out.println(lineArr[i]);
	                            
	                      i++;      
	                   }
	                    aLine = Arrays.asList(lineArr);
	                    csvList.add(aLine);
	                    p++;
	                    continue;
	               }
	               
	               if(p != 0) {
	                  int i=0;
	               for(String s : lineArr) {
	                  
	                  if(i==0) {
	                     lineArr[i] = "insert into "+ title +" values('"+lineArr[i]+"'";
	                  }
	                  else if(i == lineArr.length-1) {
	                     lineArr[i] ="'"+lineArr[i]+"');";
	                  }
	                  else {
	                     lineArr[i] = "'"+lineArr[i]+"'";
	                  }
	                  System.out.println(lineArr[i]);
	                        i++;
	               }
	               }
	                aLine = Arrays.asList(lineArr);
	                csvList.add(aLine);
	               }
	            
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                if (br != null) { 
	                    br.close(); 
	                }
	            } catch(IOException e) {
	                e.printStackTrace();
	            }
	        }
	        return csvList;
	    }
}