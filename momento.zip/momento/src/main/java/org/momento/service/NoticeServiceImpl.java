package org.momento.service;

import java.util.List;

import org.momento.domain.NoticeAttachVO;
import org.momento.domain.NoticeVO;
import org.momento.domain.Criteria;
import org.momento.domain.ReferralVO;
import org.momento.mapper.NoticeAttachMapper;
import org.momento.mapper.NoticeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class NoticeServiceImpl implements NoticeService {
	
	@Setter(onMethod_ = @Autowired)
	private NoticeMapper mapper;
	
	@Setter(onMethod_ = @Autowired)
	private NoticeAttachMapper attachMapper;

	/* 전체글 조회 */
	@Override
	public List<NoticeVO> getList(Criteria cri) {
		return mapper.getListWithPaging(cri);	
	}
	
	/* 전체글 카운팅 */
	@Override
	public int getTotal(Criteria cri) {
		return mapper.getTotalCount(cri);
	}
	
	/* 삭제글 조회 */
	@Override
	public List<NoticeVO> getDeletedList(Criteria cri) {
		return mapper.getDeletedListWithPaging(cri);
	}
	
	/* 삭제글 카운팅 */
	@Override
	public int getDeleted(Criteria cri) {
		return mapper.getDeletedCount(cri);
	}
	
	/* 공지글 조회 */
	@Override
	public List<NoticeVO> getFixedPosts() {
		return mapper.getFixedList();
	}
	
	/* 인기글 조회 */
	@Override
	public List<NoticeVO> getHotPosts() {
		return mapper.getHotList();
	}
	
	/* 글 등록 */
	@Transactional
	@Override
	public void register(NoticeVO board) {
		mapper.insertSelectKey(board);
		
		if (board.getAttachVO() == null) { return; }
		
		NoticeAttachVO attach = board.getAttachVO();
		log.info(attach);
		attach.setBno(board.getBno());
		attachMapper.insert(attach);
	}
	
	/* 글 조회 */
	@Override
	public NoticeVO get(Long bno) {
		mapper.views(bno);
		return mapper.read(bno);
	}

	/* 글 수정 */
	@Transactional
	@Override
	public boolean modify(NoticeVO board) {
		attachMapper.delete(board.getBno());
		boolean modifyResult = mapper.update(board) == 1;
		NoticeAttachVO attach = board.getAttachVO();
		
		if (modifyResult && board.getAttachVO() != null) {
			attach = board.getAttachVO();
			attach.setBno(board.getBno());
			attachMapper.insert(attach);
		}

		return modifyResult;
	}

	/* 글 삭제 */
	@Transactional
	@Override
	public boolean remove(Long bno) {
		attachMapper.delete(bno);
		return mapper.delete(bno) == 1;
	}
	
	@Override
	public boolean removeMulti(Long[] bnos, String del_res) {
		boolean removedAll = false;
		
		if (del_res.equals("delete")) {
			for (int bno=0 ; bno<bnos.length ; bno++) {
				removedAll = mapper.delete(bnos[bno]) == 1;
			}
		} else {
			for (int bno=0 ; bno<bnos.length ; bno++) {
				removedAll = mapper.restore(bnos[bno]) == 1;
			}
		}
		
		return removedAll;
	}

	/* 업로드 파일 조회 */
	@Override
	public NoticeAttachVO getAttachVO(Long bno) {
		return attachMapper.findByBno(bno);
	}
	
	/* 추천 데이터 조회 */
	@Override
	public boolean getReferrals(ReferralVO referral) {
		if ( mapper.getReferral(referral) == 1 ) return true;
		else return false;
	}
	
	/* 추천 로직 */
	@Override
	public boolean referral(ReferralVO referral) {
		int referralCnt;
		
		if (getReferrals(referral)) {
			mapper.deleteReferral(referral);
			referralCnt = -1;
		} else {
			mapper.insertReferral(referral);
			referralCnt = 1;
		}

		return mapper.updateReferrals(referralCnt, referral.getBno()) == 1;
	}

}
