package org.momento.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/sql/*")
@Log4j
public class SQLController {

	@PreAuthorize("isAuthenticated()")
	@GetMapping("/sql")
	public void sql() {}
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/csvreader")
	public void csvReader() {}
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/readerPost")
	public String csvReaderPost(@RequestParam("test") String test, RedirectAttributes rttr) throws IOException {
		SqlFile sqlReader = new SqlFile(test);
		rttr.addFlashAttribute("csvread", sqlReader.readSQL());
		rttr.addFlashAttribute("test", test);
		return "redirect:/sql/sql";
	}
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/uploadForm")
	public void uploadForm() {
		log.info("upload form");
	}
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/uploadFormAction")
	public String uploadFormPost( MultipartFile uploadFile,RedirectAttributes rttr) {
		String path = "C:\\upload"; //폴더 경로
		File Folder = new File(path);

		// 해당 디렉토리가 없을경우 디렉토리를 생성합니다.
		if (!Folder.exists()) {
			try{
			    Folder.mkdir(); //폴더 생성합니다.
			    System.out.println("폴더가 생성되었습니다.");
		        } 
		        catch(Exception e){
			    e.getStackTrace();
			}        
	         }else {
			System.out.println("이미 폴더가 생성되어 있습니다.");
		}
	    
		String uploadFolder ="C:\\upload";
		
		log.info(uploadFile.getOriginalFilename());
		File saveFile = new File(uploadFolder,"upload.csv");
		try {
			uploadFile.transferTo(saveFile);
		}catch (Exception e) {
			log.error(e.getMessage());
		}
		rttr.addFlashAttribute("sqlFile", uploadFile.getOriginalFilename());
		
		return "redirect:/sql/sql";
		
	}
		
}
