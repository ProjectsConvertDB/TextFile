package org.momento.mapper;

import java.util.List;

import org.momento.domain.BoardAttachVO;

public interface BoardAttachMapper {

	/* 파일 데이터 삽입 */
	public void insert(BoardAttachVO vo);
	
	/* 파일 데이터 삭제 */
	public void delete(Long Bno);
	
	/* `bno'번 글 조회 */
	public BoardAttachVO findByBno(Long bno);
	
	/* 잘못 업로드된 파일 삭제 */
	public List<BoardAttachVO> getOldFiles();
	
}
