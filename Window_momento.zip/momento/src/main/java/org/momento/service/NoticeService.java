package org.momento.service;

import java.util.List;

import org.momento.domain.NoticeAttachVO;
import org.momento.domain.NoticeVO;
import org.momento.domain.Criteria;
import org.momento.domain.ReferralVO;

public interface NoticeService {

	/* 전체글 조회 */
	public List<NoticeVO> getList(Criteria cri);
	
	/* 전체글 카운팅 */
	public int getTotal(Criteria cri);
	
	/* 삭제글 조회 */
	public List<NoticeVO> getDeletedList(Criteria cri);
	
	/* 삭제글 카운팅 */
	public int getDeleted(Criteria cri);
	
	/* 글 등록 */
	public void register(NoticeVO board);

	/* 글 조회 */
	public NoticeVO get(Long bno);

	/* 글 수정 */
	public boolean modify(NoticeVO board);

	/* 글 삭제 */
	public boolean remove(Long bno);
	
	public boolean removeMulti(Long[] bnos, String del_res);
	
	/* 업로드 파일 조회 */
	public NoticeAttachVO getAttachVO(Long bno);
	
	/* 추천 데이터 조회 */
	public boolean getReferrals(ReferralVO referral);
	
	/* 추천 로직 */
	public boolean referral(ReferralVO referral);

}
