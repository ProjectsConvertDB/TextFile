const str = "";

// 인풋 폼
const inputForm = document.querySelector("#inputForm");

// 페이지 내 인풋
const userName = document.querySelector("#userName");
const pNum = document.querySelector("#pNum");
const pNum2 = document.querySelector("#pNum2");

// 모달 관련
const modal = document.getElementById("modalWrap");
const closeBtn = document.getElementById("closeBtn");
const findIdArticle = document.getElementById("findIdArticle");
const findIdArticle2 = document.getElementById("findIdArticle2");

// 정규식 (아이디)
const nameReg = /^[가-힣]{2,50}$/;
// 정규식(전화번호1)
const pNumReg = /^\d{3,4}$/;
// 정규식(전화번호2)
const pNumReg2 = /^\d{4}$/;

// 이름 검증
let nameCheck = (e) => {
  e.preventDefault();
  let nameValue = userName.value;
  let message = document.querySelector("#nameMessage");

  if (nameValue === str) {
    message.innerText = `*이름을 입력해주세요`;
    message.classList.remove("valid-feedback");
    message.classList.add("invalid-feedback");
    userName.classList.remove("border-green");
    userName.classList.add("border-red");
    userName.focus();
  } else if (nameReg.test(nameValue) && nameValue !== str) {
    message.innerText = "";
    message.classList.remove("invalid-feedback");
    message.classList.add("valid-feedback");
    userName.classList.remove("border-red");
    userName.classList.add("border-green");
    pNum.focus();
    pNumCheck();
  } else if (!nameReg.test(nameValue)) {
    message.innerText = `*${nameValue}는(은) 잘못된 형식의 이름입니다. (한글2자 이상)`;
    message.classList.remove("valid-feedback");
    message.classList.add("invalid-feedback");
    userName.classList.remove("border-green");
    userName.classList.add("border-red");
    userName.focus();
  } else {
  }
};

// 두 번째 전화번호 검증
let pNumCheck = () => {
  let userPnumValue = pNum.value;
  let message = document.querySelector("#pNumMessage");

  if (userPnumValue === str) {
    message.innerText = `*전화번호를 입력해주세요.`;
    message.classList.remove("valid-feedback");
    message.classList.add("invalid-feedback");
    pNum.classList.remove("border-green");
    pNum.classList.add("border-red");
  } else if (!pNumReg.test(userPnumValue)) {
    message.innerText = `*올바른 형식이 아닙니다.`;
    message.classList.remove("valid-feedback");
    message.classList.add("invalid-feedback");
    pNum.classList.remove("border-green");
    pNum.classList.add("border-red");
  } else if (pNumReg.test(userPnumValue) && userPnumValue !== str) {
    message.innerText = "";
    message.classList.remove("invalid-feedback");
    message.classList.add("valid-feedback");
    pNum.classList.remove("border-red");
    pNum.classList.add("border-green");
    pNum2.focus();
    pNumCheck2();
  }
};

// 세 번째 전화번호 검증
let pNumCheck2 = () => {
  let userPnumValue = pNum.value;
  let userPnumValue2 = pNum2.value;
  let message = document.querySelector("#pNumMessage2");

  if (userPnumValue2 === str) {
    message.innerText = `*전화번호를 입력해주세요.`;
    message.classList.remove("valid-feedback");
    message.classList.add("invalid-feedback");
    pNum2.classList.remove("border-green");
    pNum2.classList.add("border-red");
  } else if (!pNumReg2.test(userPnumValue2)) {
    message.innerText = `*올바른 형식이 아닙니다.`;
    message.classList.remove("valid-feedback");
    message.classList.add("invalid-feedback");
    pNum2.classList.remove("border-green");
    pNum2.classList.add("border-red");
  } else if (pNumReg2.test(userPnumValue2) && userPnumValue2 !== str) {
    message.innerText = "";
    message.classList.remove("invalid-feedback");
    message.classList.add("valid-feedback");
    pNum2.classList.remove("border-red");
    pNum2.classList.add("border-green");
    openModal();
  } else {
  }
};

// 모달(서버에서 값을 비교해 결과를 출력해주는 로직 필요)
let openModal = () => {
  modal.style.display = "block";
  // 테스트용 아이디
  let idTest = "test123";
  // 예시
  if (true) {
    findIdArticle.innerText = `${userName.value}님의 아이디는`;
    findIdArticle2.innerText = `${idTest}`;
    findIdArticle2.classList.add("valid-feedback");
  } else if (false) {
    findIdArticle.innerText = `존재하지 않는 회원입니다.`;
  } else {
  }
  // "X" 클릭 시 모달 창 close
  closeBtn.addEventListener("click", closeModal);
};

let closeModal = () => (modal.style.display = "none");

// 메인 함수 실행 이벤트
inputForm.addEventListener("submit", nameCheck);
